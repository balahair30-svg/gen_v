import React, { useState } from 'react';
import {
  Briefcase,
  Code2,
  GraduationCap,
  Award,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Printer,
  Layers,
  Sparkles,
  CheckCircle2,
  Copy,
  Check,
  Globe,
  Share2,
  Box,
  Eye,
  Info,
  Terminal,
} from 'lucide-react';
import { cvData, ExperienceItem, SkillGroup } from './data/cvData';
import { ThreeCanvas } from './components/ThreeCanvas';

export default function App() {
  const [inspectMode, setInspectMode] = useState<boolean>(false);
  const [activeSkillCategory, setActiveSkillCategory] = useState<number>(0);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [is3DFullscreen, setIs3DFullscreen] = useState<boolean>(false);
  const [showCssDocModal, setShowCssDocModal] = useState<boolean>(false);

  // Copy helper
  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 ${inspectMode ? 'inspect-mode-active' : ''}`}>
      {/* ====================================================================
          TECHNIQUE 2: INTERNAL STYLES (<style> Tag In Document)
          ==================================================================== */}
      <style id="cv-internal-styles">{`
        /* Internal Style: Keyframe Animations */
        @keyframes internalGlowShimmer {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        @keyframes internalPulseRadar {
          0% { transform: scale(0.95); opacity: 0.9; }
          50% { transform: scale(1.1); opacity: 0.4; }
          100% { transform: scale(0.95); opacity: 0.9; }
        }

        @keyframes internalFloatBadge {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-3px); }
        }

        /* Internal Style: Hero Gradient Banner */
        .int-hero-gradient-mesh {
          background: radial-gradient(circle at 15% 25%, rgba(16, 185, 129, 0.15) 0%, transparent 45%),
                      radial-gradient(circle at 85% 75%, rgba(6, 182, 212, 0.12) 0%, transparent 50%),
                      radial-gradient(circle at 50% 50%, rgba(15, 23, 42, 0.8) 0%, #090d16 100%);
          border-bottom: 1px solid rgba(148, 163, 184, 0.12);
        }

        /* Internal Style: Interactive Skill Pills */
        .int-skill-category-tab {
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          border-radius: 10px;
          border: 1px solid rgba(148, 163, 184, 0.15);
        }
        .int-skill-category-tab.active {
          background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(6, 182, 212, 0.15) 100%);
          border-color: rgba(16, 185, 129, 0.5);
          color: #34d399;
          box-shadow: 0 4px 16px -2px rgba(16, 185, 129, 0.25);
        }

        /* Internal Style: Glassmorphic Floating Panel */
        .int-glass-panel {
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          background: rgba(15, 23, 42, 0.85);
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        /* Internal Style: Decorative Timeline Node Accent */
        .int-timeline-node-accent {
          box-shadow: 0 0 12px rgba(16, 185, 129, 0.6);
        }

        /* Internal Style: Card Hover Glow Pseudo-Element */
        .int-interactive-card {
          position: relative;
          transition: transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease;
        }
        .int-interactive-card:hover {
          transform: translateY(-2px);
          border-color: rgba(16, 185, 129, 0.4);
          box-shadow: 0 12px 28px -8px rgba(0, 0, 0, 0.7), 0 0 16px -2px rgba(16, 185, 129, 0.2);
        }

        /* Internal Style: Print Specific Tweaks */
        @media print {
          .int-hero-gradient-mesh {
            background: #ffffff !important;
            border-bottom: 2px solid #059669 !important;
          }
          .int-glass-panel {
            background: #ffffff !important;
            backdrop-filter: none !important;
          }
          .int-interactive-card {
            transform: none !important;
            box-shadow: none !important;
          }
        }
      `}</style>

      {/* ====================================================================
          TOP NAVIGATION & ACTION BAR (External Styles + Inline Styles)
          ==================================================================== */}
      <header
        className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md no-print"
        // Inline style for dynamic sticky shadow and border highlight
        style={{
          boxShadow: '0 4px 20px -2px rgba(0, 0, 0, 0.5)',
        }}
      >
        <div className="ext-cv-container flex flex-wrap items-center justify-between py-3 gap-3">
          {/* Logo / Identity */}
          <div className="flex items-center gap-3">
            {/* Inline style for custom monogram badge geometry */}
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl font-bold text-white shadow-md"
              style={{
                background: 'linear-gradient(135deg, #10b981 0%, #06b6d4 100%)',
                boxShadow: '0 0 15px rgba(16, 185, 129, 0.4)',
                fontFamily: 'var(--cv-font-sans)',
              }}
            >
              NT
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white">
                  Nasrul Thiab
                </span>
                <span className="ext-badge">CV Profesional</span>
              </div>
              <p className="text-xs text-slate-400">Sumatra Barat • Web & 3D Specialist</p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2">
            {/* CSS Technique Inspector Toggle Button */}
            <button
              onClick={() => setInspectMode(!inspectMode)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                inspectMode
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500 shadow-md shadow-amber-500/20'
                  : 'bg-slate-900 text-slate-300 border border-slate-700/80 hover:border-slate-500 hover:text-white'
              }`}
              title="Aktifkan highlight warna untuk melihat teknik Inline, Internal, dan External style"
            >
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>{inspectMode ? 'Mode Inspeksi: ON' : 'Inspeksi 3 Gaya CSS'}</span>
            </button>

            {/* CSS Education Modal Button */}
            <button
              onClick={() => setShowCssDocModal(true)}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700/80 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-cyan-300 hover:border-cyan-500/60 hover:bg-slate-800 transition-colors"
              title="Lihat dokumentasi penerapan Inline, Internal, dan External Stylesheet"
            >
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Penerapan CSS</span>
            </button>

            {/* WhatsApp Quick Chat */}
            <a
              href={`https://wa.me/${cvData.personal.whatsapp}?text=Halo%20Nasrul%20Thiab,%20saya%20melihat%20CV%20Anda%20dan%20tertarik%20untuk%20berdiskusi.`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold text-white transition-all hover:brightness-110"
              // Inline style for WhatsApp brand color & elevation
              style={{
                backgroundColor: '#25D366',
                boxShadow: '0 2px 10px rgba(37, 211, 102, 0.3)',
              }}
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>

            {/* Print / Save PDF Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20 transition-colors"
              title="Cetak CV atau Simpan sebagai PDF (A4 Clean Layout)"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-400" />
              <span>Cetak / PDF</span>
            </button>
          </div>
        </div>

        {/* CSS Technique Inspector Banner Alert */}
        {inspectMode && (
          <div className="border-t border-amber-500/30 bg-amber-500/10 px-4 py-2 text-xs text-amber-200">
            <div className="ext-cv-container flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Mode Inspeksi Aktif:</strong> Elemen diberi garis putus-putus berwarna
                  sesuai teknik gayanya.
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="flex items-center gap-1 text-[11px]">
                  <span className="h-2.5 w-2.5 rounded-sm bg-purple-500 inline-block border border-purple-300" />
                  <strong>External CSS</strong> (cv-external.css)
                </span>
                <span className="flex items-center gap-1 text-[11px]">
                  <span className="h-2.5 w-2.5 rounded-sm bg-cyan-500 inline-block border border-cyan-300" />
                  <strong>Internal CSS</strong> (&lt;style&gt; tag)
                </span>
                <span className="flex items-center gap-1 text-[11px]">
                  <span className="h-2.5 w-2.5 rounded-sm bg-amber-500 inline-block border border-amber-300" />
                  <strong>Inline Style</strong> (style=&quot;...&quot;)
                </span>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* ====================================================================
          HERO & HEADER BANNER
          Combines:
          1. External Classes (.ext-cv-container)
          2. Internal Styles (.int-hero-gradient-mesh)
          3. Inline Styles (Dynamic padding, accent colors)
          4. Three.js 3D Scene
          ==================================================================== */}
      <section
        className="int-hero-gradient-mesh py-8 md:py-12 relative overflow-hidden inspect-int-target"
        // Inline style for dynamic min-height and padding customization
        style={{
          borderBottomColor: 'rgba(16, 185, 129, 0.25)',
        }}
      >
        <div className="ext-cv-container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Col: Personal Credentials & Core Bio */}
            <div className="lg:col-span-7 space-y-5">
              {/* Status Pill */}
              <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-950/60 px-3.5 py-1 text-xs font-semibold text-emerald-300">
                <span
                  className="h-2 w-2 rounded-full"
                  // Inline style for custom color code
                  style={{ backgroundColor: '#10b981' }}
                />
                <span>{cvData.personal.status}</span>
                {inspectMode && (
                  <span className="ext-css-inspector-badge badge-inline-style ml-1">
                    inline-style
                  </span>
                )}
              </div>

              {/* Full Name & Title */}
              <div>
                <h1
                  className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-2"
                  // Inline style demonstrating custom typography letter-spacing & line-height
                  style={{
                    letterSpacing: '-0.025em',
                    lineHeight: '1.15',
                  }}
                >
                  {cvData.personal.name}
                </h1>
                <p
                  className="text-lg sm:text-xl font-medium text-emerald-400"
                  // Inline style for accent text glow
                  style={{
                    textShadow: '0 0 20px rgba(16, 185, 129, 0.3)',
                  }}
                >
                  {cvData.personal.title}
                </p>
              </div>

              {/* Contact Information Bar (Grid of Direct Touchpoints) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Email Item */}
                <div
                  className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 transition-all hover:border-emerald-500/40"
                  // Inline style for card background tint
                  style={{ background: 'rgba(15, 23, 42, 0.7)' }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="block text-[10px] uppercase font-bold text-slate-400">Email</span>
                      <a
                        href={`mailto:${cvData.personal.email}`}
                        className="block text-xs font-medium text-slate-200 hover:text-emerald-400 truncate"
                        title={cvData.personal.email}
                      >
                        {cvData.personal.email}
                      </a>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(cvData.personal.email, 'email')}
                    className="shrink-0 p-1.5 text-slate-400 hover:text-emerald-400 transition-colors"
                    title="Salin Email"
                  >
                    {copiedField === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Phone & WA Item */}
                <div
                  className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 transition-all hover:border-emerald-500/40"
                  style={{ background: 'rgba(15, 23, 42, 0.7)' }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="block text-[10px] uppercase font-bold text-slate-400">Nomor Kontak / WA</span>
                      <a
                        href={`tel:${cvData.personal.phone.replace(/\s+/g, '')}`}
                        className="block text-xs font-medium text-slate-200 hover:text-cyan-400 truncate"
                      >
                        {cvData.personal.phone}
                      </a>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(cvData.personal.phone, 'phone')}
                    className="shrink-0 p-1.5 text-slate-400 hover:text-cyan-400 transition-colors"
                    title="Salin Nomor"
                  >
                    {copiedField === 'phone' ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Location / Alamat Item */}
                <div
                  className="flex items-center rounded-xl border border-slate-800 bg-slate-900/80 p-2.5"
                  style={{ background: 'rgba(15, 23, 42, 0.7)' }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="block text-[10px] uppercase font-bold text-slate-400">Domisili / Alamat</span>
                      <span className="block text-xs font-semibold text-slate-200 truncate">
                        {cvData.personal.address}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Portfolio / Website */}
                <div
                  className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/80 p-2.5"
                  style={{ background: 'rgba(15, 23, 42, 0.7)' }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="block text-[10px] uppercase font-bold text-slate-400">Portofolio</span>
                      <span className="block text-xs font-semibold text-slate-200 truncate">
                        {cvData.personal.portfolio}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">LIVE</span>
                </div>
              </div>

              {/* Summary Paragraph */}
              <div
                className="rounded-xl border border-slate-800/80 bg-slate-900/60 p-4 text-xs sm:text-sm text-slate-300 leading-relaxed inspect-ext-target"
              >
                <div className="flex items-center gap-1.5 font-bold text-slate-200 mb-1.5 text-xs uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Ringkasan Profesional</span>
                  {inspectMode && (
                    <span className="ext-css-inspector-badge badge-ext-sheet ml-auto">
                      external-sheet
                    </span>
                  )}
                </div>
                <p>{cvData.personal.summary}</p>
              </div>
            </div>

            {/* Right Col: Three.js Interactive 3D Showcase */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="w-full">
                <ThreeCanvas
                  isFullMode={is3DFullscreen}
                  onToggleFullMode={() => setIs3DFullscreen(!is3DFullscreen)}
                />
                <p className="mt-2 text-center text-[11px] text-slate-400">
                  <span className="font-semibold text-emerald-400">3D Interactive Monogram:</span>{' '}
                  Putar, perbesar, dan ubah material inti menggunakan Three.js PBR.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ====================================================================
          MAIN CONTENT AREA (2-Column Responsive Layout via External Grid)
          ==================================================================== */}
      <main className="ext-cv-container py-10">
        <div className="ext-cv-grid-layout">
          {/* ================================================================
              LEFT COLUMN: Skills, Education, Certifications, Languages
              ================================================================ */}
          <aside className="space-y-6">
            {/* 1. KETERAMPILAN TEKNIS (Detailed Technical Skills) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <Code2 className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-base">Keterampilan Teknis</h2>
                  <p className="text-[11px] text-slate-400 font-normal">Level Kemahiran & Pengalaman</p>
                </div>
                {inspectMode && (
                  <span className="ext-css-inspector-badge badge-ext-sheet ml-auto">
                    ext-card
                  </span>
                )}
              </div>

              {/* Category Selector Tabs (Internal CSS class .int-skill-category-tab) */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {cvData.skillGroups.map((group, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveSkillCategory(idx)}
                    className={`int-skill-category-tab text-[11px] font-semibold px-2.5 py-1 text-left transition-all ${
                      activeSkillCategory === idx ? 'active' : 'text-slate-400 bg-slate-900/60 hover:text-slate-200'
                    }`}
                  >
                    {idx === 0 ? 'HTML & CSS Styling' : idx === 1 ? 'Frontend & 3D' : 'Backend & Cloud'}
                  </button>
                ))}
              </div>

              {/* Skills List with Dynamic Inline Progress Bars */}
              <div className="space-y-3.5">
                <p className="text-[11px] text-slate-400 italic">
                  {cvData.skillGroups[activeSkillCategory].description}
                </p>

                {cvData.skillGroups[activeSkillCategory].skills.map((skill, sIdx) => (
                  <div key={sIdx} className="group">
                    <div className="flex items-center justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-200 group-hover:text-emerald-300 transition-colors">
                        {skill.name}
                      </span>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="text-slate-400 font-mono">{skill.years}</span>
                        {/* Inline style for badge color */}
                        <span
                          className="font-bold font-mono px-1.5 py-0.2 rounded"
                          style={{
                            color: skill.accentColor,
                            backgroundColor: `${skill.accentColor}18`,
                          }}
                        >
                          {skill.level}%
                        </span>
                      </div>
                    </div>

                    {/* External Meter Background (.ext-skill-meter-bg) + Inline Dynamic Width & Gradient */}
                    <div className="ext-skill-meter-bg">
                      <div
                        className="ext-skill-meter-fill inspect-inline-target"
                        // Inline style for dynamic width and unique color gradient per skill
                        style={{
                          width: `${skill.level}%`,
                          background: `linear-gradient(90deg, ${skill.accentColor}, #38bdf8)`,
                          boxShadow: `0 0 10px ${skill.accentColor}44`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* CSS Technique Highlight Note inside Skills */}
              <div
                className="mt-5 rounded-lg border border-amber-500/20 bg-amber-500/5 p-2.5 text-[11px] text-amber-200/90 inspect-inline-target"
                // Inline style for educational indicator
                style={{ borderLeft: '3px solid #f59e0b' }}
              >
                <div className="flex items-center gap-1 font-bold text-amber-300 mb-0.5">
                  <Sparkles className="w-3 h-3" />
                  <span>Teknik Inline Style di Keterampilan:</span>
                </div>
                Lebar meter persentase (e.g.{' '}
                <code className="text-amber-300 font-mono">style=&quot;width: 98%&quot;</code>) dan warna gradien diatur secara langsung via Inline Style untuk akurasi data runtime.
              </div>
            </div>

            {/* 2. PENDIDIKAN (Education) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-base">Pendidikan</h2>
                  <p className="text-[11px] text-slate-400 font-normal">Latar Belakang Akademis</p>
                </div>
              </div>

              <div className="space-y-4">
                {cvData.education.map((edu, idx) => (
                  <div key={idx} className="relative">
                    <span className="ext-badge-cyan text-[10px] font-mono mb-1 inline-block">
                      {edu.year}
                    </span>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-100 leading-snug">
                      {edu.degree}
                    </h3>
                    <p className="text-xs font-semibold text-emerald-400 mt-0.5">
                      {edu.institution}
                    </p>
                    <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{edu.location}</span>
                    </p>
                    <div
                      className="mt-2 rounded bg-slate-900/90 border border-slate-800 p-2 text-[11px] text-slate-300"
                      // Inline style for subtle border accent
                      style={{ borderLeft: '3px solid #06b6d4' }}
                    >
                      <strong className="text-cyan-300 block mb-0.5">{edu.gpa}</strong>
                      <span>{edu.notes}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. SERTIFIKASI PROFESIONAL (Certifications) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-base">Sertifikasi</h2>
                  <p className="text-[11px] text-slate-400 font-normal">Kualifikasi Industri</p>
                </div>
              </div>

              <div className="space-y-3">
                {cvData.certifications.map((cert, idx) => (
                  <div
                    key={idx}
                    className="rounded-lg border border-slate-800 bg-slate-900/60 p-2.5 transition-all hover:border-slate-700"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-slate-200 leading-tight">
                        {cert.name}
                      </h4>
                      <span
                        className="text-[10px] font-mono px-1.5 py-0.5 rounded shrink-0"
                        // Inline style for cert badge
                        style={{
                          backgroundColor: `${cert.badgeColor}22`,
                          color: cert.badgeColor,
                          border: `1px solid ${cert.badgeColor}55`,
                        }}
                      >
                        {cert.year}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{cert.issuer}</p>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
                      ID: {cert.credentialId}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. BAHASA (Languages) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-base">Penguasaan Bahasa</h2>
                  <p className="text-[11px] text-slate-400 font-normal">Komunikasi & Kolaborasi</p>
                </div>
              </div>

              <div className="space-y-2.5">
                {cvData.languages.map((lang, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <div>
                      <span className="font-semibold text-slate-200 block">{lang.name}</span>
                      <span className="text-[11px] text-slate-400">{lang.level}</span>
                    </div>
                    <div className="w-20">
                      <div className="ext-skill-meter-bg">
                        <div
                          className="ext-skill-meter-fill"
                          style={{
                            width: `${lang.proficiency}%`,
                            backgroundColor: '#10b981',
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>

          {/* ================================================================
              RIGHT COLUMN: Detailed Work Experiences, Featured Projects, CSS Architecture
              ================================================================ */}
          <section className="space-y-6">
            {/* 1. PENGALAMAN KERJA MENDETAIL (Work Experience) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-lg">Pengalaman Kerja</h2>
                  <p className="text-xs text-slate-400 font-normal">
                    Jejak Rekam Profesional & Pencapaian Terukur
                  </p>
                </div>
                {inspectMode && (
                  <span className="ext-css-inspector-badge badge-ext-sheet ml-auto">
                    ext-timeline
                  </span>
                )}
              </div>

              {/* Timeline Container (.ext-timeline-wrapper from cv-external.css) */}
              <div className="ext-timeline-wrapper">
                {cvData.experiences.map((exp: ExperienceItem) => (
                  <div key={exp.id} className="ext-timeline-item">
                    {/* Timeline Node Dot */}
                    <div
                      className="ext-timeline-dot int-timeline-node-accent inspect-inline-target"
                      // Inline style for dynamic custom color code per company
                      style={{ borderColor: exp.accentColor }}
                    />

                    {/* Experience Card */}
                    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 transition-all hover:border-slate-700">
                      {/* Role Header */}
                      <div className="flex flex-wrap items-start justify-between gap-2 mb-1.5">
                        <div>
                          <h3 className="font-bold text-sm sm:text-base text-white">
                            {exp.role}
                          </h3>
                          <div className="flex flex-wrap items-center gap-2 text-xs mt-0.5">
                            <span
                              className="font-semibold"
                              // Inline style for company text color
                              style={{ color: exp.accentColor }}
                            >
                              {exp.company}
                            </span>
                            <span className="text-slate-500">•</span>
                            <span className="text-slate-400 flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-slate-400" />
                              {exp.location}
                            </span>
                          </div>
                        </div>

                        {/* Period & Employment Type Badge */}
                        <div className="flex items-center gap-1.5">
                          <span className="ext-badge-secondary font-mono text-[11px]">
                            {exp.period}
                          </span>
                          <span
                            className="rounded-full text-[10px] font-semibold px-2 py-0.5"
                            style={{
                              backgroundColor: `${exp.accentColor}18`,
                              color: exp.accentColor,
                              border: `1px solid ${exp.accentColor}44`,
                            }}
                          >
                            {exp.type}
                          </span>
                        </div>
                      </div>

                      {/* Role Overview */}
                      <p className="text-xs text-slate-300 leading-relaxed my-2.5">
                        {exp.description}
                      </p>

                      {/* Key Highlights / Achievements */}
                      <div className="space-y-1.5 my-3">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                          Tanggung Jawab & Pencapaian Utama:
                        </span>
                        {exp.highlights.map((item, hIdx) => (
                          <div key={hIdx} className="flex items-start gap-2 text-xs text-slate-300">
                            <CheckCircle2
                              className="w-3.5 h-3.5 shrink-0 mt-0.5"
                              style={{ color: exp.accentColor }}
                            />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>

                      {/* Tech Stack Badges */}
                      <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mr-1">
                          Tech:
                        </span>
                        {exp.techStack.map((tech, tIdx) => (
                          <span
                            key={tIdx}
                            className="rounded-md px-2 py-0.5 text-[10px] font-mono font-medium text-slate-300 bg-slate-800/80 border border-slate-700/60"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. PORTOFOLIO PROYEK PILIHAN (Featured Projects) */}
            <div className="ext-card inspect-ext-target">
              <div className="ext-section-title">
                <div className="ext-section-icon">
                  <Box className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-lg">Proyek Unggulan</h2>
                  <p className="text-xs text-slate-400 font-normal">
                    Karya Pilihan & Bukti Kemampuan Eksekusi
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cvData.projects.map((proj) => (
                  <div
                    key={proj.id}
                    className="int-interactive-card rounded-xl border border-slate-800 bg-slate-900/60 p-4 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <span className="ext-badge-cyan text-[10px]">{proj.category}</span>
                        <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                          {proj.role}
                        </span>
                      </div>
                      <h3 className="font-bold text-sm text-slate-100 group-hover:text-emerald-300">
                        {proj.title}
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed mt-2">
                        {proj.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800">
                      <div className="mb-2 text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        <span>{proj.metrics}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {proj.tags.map((t, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. DOKUMENTASI & DEMO IMPLEMENTASI 3 TEKNIK CSS */}
            <div
              className="rounded-2xl border border-cyan-500/30 bg-slate-900/90 p-5 shadow-xl relative overflow-hidden inspect-int-target"
              // Inline style for card glow
              style={{
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.2)',
              }}
            >
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">
                      Penerapan 3 Teknik CSS (Inline, Internal, External)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Bukti Implementasi Teknis Sesuai Spesifikasi Permintaan
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setShowCssDocModal(true)}
                  className="flex items-center gap-1.5 rounded-lg border border-cyan-500/50 bg-cyan-500/10 px-3 py-1.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/20 transition-all"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Buka Dokumentasi & Kode</span>
                </button>
              </div>

              {/* 3 Interactive Cards Demonstrating Each Technique */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                {cvData.cssTechniquesDoc.map((tech, idx) => (
                  <div
                    key={idx}
                    className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5 flex flex-col justify-between"
                    // Inline style for card border top
                    style={{ borderTop: `3px solid ${tech.color}` }}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span
                          className="text-[10px] font-mono font-bold px-2 py-0.5 rounded"
                          style={{
                            backgroundColor: `${tech.color}22`,
                            color: tech.color,
                            border: `1px solid ${tech.color}55`,
                          }}
                        >
                          {tech.badge}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Teknik #{idx + 1}</span>
                      </div>

                      <h4 className="font-bold text-xs text-slate-100 mb-1">{tech.type}</h4>
                      <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                        {tech.purpose}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                      <strong className="text-slate-300 block mb-0.5">Keunggulan:</strong>
                      {tech.benefits}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* ====================================================================
          FOOTER
          ==================================================================== */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-8 no-print">
        <div className="ext-cv-container flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            <p className="font-semibold text-slate-200">
              CV Profesional Nasrul Thiab • Sumatra Barat
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Dibuat dengan HTML5, CSS3 (Inline, Internal, External Style), React & Three.js 3D PBR.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={`mailto:${cvData.personal.email}`}
              className="hover:text-emerald-400 transition-colors"
            >
              {cvData.personal.email}
            </a>
            <span>•</span>
            <a
              href={`tel:${cvData.personal.phone.replace(/\s+/g, '')}`}
              className="hover:text-emerald-400 transition-colors"
            >
              {cvData.personal.phone}
            </a>
            <span>•</span>
            <button
              onClick={handlePrint}
              className="text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
            >
              <Printer className="w-3 h-3" />
              <span>Cetak Versi PDF</span>
            </button>
          </div>
        </div>
      </footer>

      {/* ====================================================================
          CSS TECHNIQUES EDUCATIONAL MODAL
          ==================================================================== */}
      {showCssDocModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm no-print">
          <div
            className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-2xl text-slate-200"
            style={{
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8), 0 0 30px rgba(6, 182, 212, 0.2)',
            }}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  <Code2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-white">
                    Arsitektur HTML & CSS: 3 Teknik Styling
                  </h3>
                  <p className="text-xs text-slate-400">
                    Penerapan Inline Style, Internal Style, dan External Stylesheet pada CV Nasrul Thiab
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCssDocModal(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="space-y-6 text-xs sm:text-sm">
              {/* External CSS Explanation */}
              <div className="rounded-xl border border-purple-500/30 bg-purple-950/20 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-purple-300 text-sm flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-purple-400 inline-block" />
                    1. External Stylesheet (cv-external.css)
                  </span>
                  <span className="text-[10px] font-mono text-purple-400">/src/cv-external.css</span>
                </div>
                <p className="text-slate-300 leading-relaxed mb-3">
                  File eksternal yang dihubungkan ke dokumen HTML. Berisi definisi sistem desain root, variabel warna (<code className="font-mono text-purple-300">--cv-primary</code>, <code className="font-mono text-purple-300">--cv-bg-card</code>), layout grid responsif multi-kolom (<code className="font-mono text-purple-300">.ext-cv-grid-layout</code>), kartu CV, dan aturan cetak (<code className="font-mono text-purple-300">@media print</code>).
                </p>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-purple-200 border border-purple-500/20">
                  <span className="text-slate-500">/* Contoh cuplikan cv-external.css */</span><br />
                  :root &#123; --cv-primary: #10b981; --cv-bg-card: #0f172a; &#125;<br />
                  .ext-cv-grid-layout &#123; display: grid; grid-template-columns: 360px 1fr; &#125;<br />
                  @media print &#123; .no-print &#123; display: none !important; &#125; &#125;
                </div>
              </div>

              {/* Internal CSS Explanation */}
              <div className="rounded-xl border border-cyan-500/30 bg-cyan-950/20 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-cyan-300 text-sm flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-cyan-400 inline-block" />
                    2. Internal Style (&lt;style id=&quot;cv-internal-styles&quot;&gt;)
                  </span>
                  <span className="text-[10px] font-mono text-cyan-400">&lt;style&gt; block</span>
                </div>
                <p className="text-slate-300 leading-relaxed mb-3">
                  Gaya CSS yang disematkan langsung di dalam dokumen pada blok <code className="font-mono text-cyan-300">&lt;style&gt;</code>. Digunakan untuk animasi keyframes kustom (<code className="font-mono text-cyan-300">@keyframes internalGlowShimmer</code>), efek mesh gradient hero (<code className="font-mono text-cyan-300">.int-hero-gradient-mesh</code>), tab filter dinamis, dan efek hover transisi visual.
                </p>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-cyan-200 border border-cyan-500/20">
                  <span className="text-slate-500">&lt;!-- Contoh cuplikan internal &lt;style&gt; --&gt;</span><br />
                  @keyframes internalPulseRadar &#123; 0% &#123; transform: scale(0.95); &#125; 100% &#123; transform: scale(1.05); &#125; &#125;<br />
                  .int-hero-gradient-mesh &#123; background: radial-gradient(circle, rgba(16,185,129,0.15), transparent); &#125;
                </div>
              </div>

              {/* Inline CSS Explanation */}
              <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-amber-400 inline-block" />
                    3. Inline Style (style=&quot;...&quot;)
                  </span>
                  <span className="text-[10px] font-mono text-amber-400">style=&#123;&#123; ... &#125;&#125;</span>
                </div>
                <p className="text-slate-300 leading-relaxed mb-3">
                  Gaya yang dituliskan langsung pada atribut elemen HTML. Digunakan untuk nilai dinamis berbasis data runtime seperti kalkulasi persentase bar keahlian (<code className="font-mono text-amber-300">width: skill.level%</code>), warna aksen spesifik tiap peran pekerjaan, dan bayangan dinamis.
                </p>
                <div className="rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-amber-200 border border-amber-500/20">
                  <span className="text-slate-500">&lt;!-- Contoh cuplikan inline style --&gt;</span><br />
                  &lt;div style=&quot;width: 98%; background: linear-gradient(90deg, #10b981, #38bdf8);&quot;&gt;&lt;/div&gt;<br />
                  &lt;span style=&quot;border-color: #10b981; color: #10b981;&quot;&gt;Lead Developer&lt;/span&gt;
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowCssDocModal(false)}
                className="rounded-lg bg-emerald-600 px-5 py-2 text-xs font-bold text-white hover:bg-emerald-500 transition-colors"
              >
                Tutup Dokumentasi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
