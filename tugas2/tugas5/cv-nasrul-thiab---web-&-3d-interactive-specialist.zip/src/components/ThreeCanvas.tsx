import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

interface ThreeCanvasProps {
  isFullMode?: boolean;
  onToggleFullMode?: () => void;
}

export type ThemePreset = 'emerald' | 'cyan' | 'titanium' | 'amber';

export const ThreeCanvas: React.FC<ThreeCanvasProps> = ({
  isFullMode = false,
  onToggleFullMode,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isControlsOpen, setIsControlsOpen] = useState(true);
  const [activeTheme, setActiveTheme] = useState<ThemePreset>('emerald');
  const [wireframe, setWireframe] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);
  const [cameraView, setCameraView] = useState<'front' | 'iso' | 'top'>('iso');

  // Mutable refs to interact with Three.js scene without full re-render
  const sceneContextRef = useRef<{
    controls?: OrbitControls;
    materials?: {
      outerCrystal?: THREE.MeshPhysicalMaterial;
      innerCore?: THREE.MeshStandardMaterial;
      ring1?: THREE.MeshStandardMaterial;
      ring2?: THREE.MeshStandardMaterial;
      beacons?: THREE.MeshStandardMaterial;
      plate?: THREE.MeshStandardMaterial;
    };
    camera?: THREE.PerspectiveCamera;
    group?: THREE.Group;
    targetCameraPos?: THREE.Vector3;
    isTransitioning?: boolean;
  }>({});

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL per Three.js guidelines
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x090d16, 0.04);

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(3.8, 2.5, 4.2);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 2. Studio Environment Reflection via RoomEnvironment
    try {
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      const roomEnv = new RoomEnvironment();
      scene.environment = pmremGenerator.fromScene(roomEnv, 0.04).texture;
      pmremGenerator.dispose();
      roomEnv.dispose();
    } catch {
      // Fallback if environment map fails
    }

    // 3. Studio Lighting Rig (Key, Fill, Rim)
    const keyLight = new THREE.DirectionalLight(0xfff6eb, 2.2);
    keyLight.position.set(4, 7, 5);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
      const d = 3.5;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
    }
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x090d16, 1.2);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight(0x10b981, 2.5);
    rimLight.position.set(-5, 3, -4);
    scene.add(rimLight);

    // 4. Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 12;
    controls.minDistance = 2;
    controls.maxPolarAngle = Math.PI / 2 + 0.15;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 1.2;

    // 5. Procedural Texture for Monogram "NT" Plate
    const createMonogramTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Deep obsidian background with metallic grid
        ctx.fillStyle = '#0b1120';
        ctx.fillRect(0, 0, 512, 512);

        // Tech grid lines
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.18)';
        ctx.lineWidth = 2;
        for (let i = 40; i < 512; i += 40) {
          ctx.beginPath();
          ctx.moveTo(i, 0);
          ctx.lineTo(i, 512);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(0, i);
          ctx.lineTo(512, i);
          ctx.stroke();
        }

        // Circular ring border
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 10;
        ctx.beginPath();
        ctx.arc(256, 256, 200, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(6, 182, 212, 0.8)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(256, 256, 220, 0, Math.PI * 2);
        ctx.stroke();

        // Monogram Typography
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 150px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('NT', 256, 230);

        // Subtitle
        ctx.fillStyle = '#34d399';
        ctx.font = '600 28px monospace';
        ctx.fillText('NASRUL THIAB', 256, 330);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '500 20px monospace';
        ctx.fillText('SUMATRA BARAT', 256, 370);
      }
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
      return texture;
    };

    // Procedural Contact Shadow
    const createContactShadowTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const gradient = ctx.createRadialGradient(128, 128, 10, 128, 128, 120);
        gradient.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
        gradient.addColorStop(0.4, 'rgba(0, 0, 0, 0.35)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 256, 256);
      }
      const texture = new THREE.CanvasTexture(canvas);
      return texture;
    };

    // 6. Composite Procedural Model (3-12 parts assembled in a THREE.Group)
    const rootGroup = new THREE.Group();
    rootGroup.position.set(0, 0, 0);

    // Materials definition with varied roughness / metalness
    const outerCrystalMat = new THREE.MeshPhysicalMaterial({
      color: 0x10b981,
      metalness: 0.85,
      roughness: 0.18,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      wireframe: false,
    });

    const innerCoreMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0891b2,
      emissiveIntensity: 0.8,
      roughness: 0.45,
      metalness: 0.2,
    });

    const ring1Mat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.95,
      roughness: 0.15,
    });

    const ring2Mat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.9,
      roughness: 0.25,
    });

    const beaconMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.8,
      roughness: 0.3,
    });

    const monogramTexture = createMonogramTexture();
    const plateMat = new THREE.MeshStandardMaterial({
      map: monogramTexture,
      roughness: 0.3,
      metalness: 0.6,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });

    // Part 1: Primary Outer Faceted Polyhedron Crystal
    const outerGeo = new THREE.IcosahedronGeometry(1.2, 0);
    const outerMesh = new THREE.Mesh(outerGeo, outerCrystalMat);
    outerMesh.castShadow = !isSoftwareGl;
    outerMesh.receiveShadow = !isSoftwareGl;
    rootGroup.add(outerMesh);

    // Part 2: Inner Core Seed
    const innerGeo = new THREE.OctahedronGeometry(0.65, 0);
    const innerMesh = new THREE.Mesh(innerGeo, innerCoreMat);
    rootGroup.add(innerMesh);

    // Part 3: Equatorial Gimbal Ring
    const ring1Geo = new THREE.TorusGeometry(1.75, 0.045, 16, 90);
    const ring1Mesh = new THREE.Mesh(ring1Geo, ring1Mat);
    ring1Mesh.rotation.x = Math.PI / 2;
    rootGroup.add(ring1Mesh);

    // Part 4: Meridian Gimbal Ring
    const ring2Geo = new THREE.TorusGeometry(1.6, 0.04, 16, 90);
    const ring2Mesh = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2Mesh.rotation.y = Math.PI / 4;
    rootGroup.add(ring2Mesh);

    // Parts 5, 6, 7, 8: Four Orbital Beacon Sensors on Ring 1
    const beaconGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.25, 12);
    const beaconAngles = [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2];
    beaconAngles.forEach((angle) => {
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.set(Math.cos(angle) * 1.75, 0, Math.sin(angle) * 1.75);
      beacon.rotation.z = Math.PI / 2;
      rootGroup.add(beacon);
    });

    // Part 9: Central Tech Monogram Plate (Double-sided disc floating beneath the core)
    const plateGeo = new THREE.CylinderGeometry(0.85, 0.85, 0.05, 32);
    const plateMesh = new THREE.Mesh(plateGeo, plateMat);
    plateMesh.position.set(0, -1.35, 0);
    plateMesh.castShadow = !isSoftwareGl;
    rootGroup.add(plateMesh);

    // Part 10: Ground Radial Contact Shadow
    const shadowGeo = new THREE.PlaneGeometry(4.5, 4.5);
    const shadowTexture = createContactShadowTexture();
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -1.65;
    scene.add(shadowMesh);

    // Part 11: Atmospheric Procedural Particle Stardust
    const particleCount = 80;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 8;
      particlePositions[i + 1] = (Math.random() - 0.5) * 6;
      particlePositions[i + 2] = (Math.random() - 0.5) * 8;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x34d399,
      size: 0.04,
      transparent: true,
      opacity: 0.5,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    scene.add(rootGroup);

    // Save refs for UI controls
    sceneContextRef.current = {
      controls,
      materials: {
        outerCrystal: outerCrystalMat,
        innerCore: innerCoreMat,
        ring1: ring1Mat,
        ring2: ring2Mat,
        beacons: beaconMat,
        plate: plateMat,
      },
      camera,
      group: rootGroup,
      targetCameraPos: camera.position.clone(),
      isTransitioning: false,
    };

    // 7. Lossless 60fps Loop with Software WebGL Guard & Exponential Damping
    let frameId = 0;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Procedural kinematics: multi-axis coordinated rotations
      outerMesh.rotation.y += delta * 0.45;
      outerMesh.rotation.x += delta * 0.25;

      innerMesh.rotation.y -= delta * 0.7;
      innerMesh.rotation.z += delta * 0.35;

      ring1Mesh.rotation.z += delta * 0.3;
      ring2Mesh.rotation.x += delta * 0.25;

      // Gentle floating levitation on Y axis
      rootGroup.position.y = Math.sin(elapsedTime * 1.5) * 0.1;

      // Particle subtle drifting
      particles.rotation.y = elapsedTime * 0.03;

      // Damped camera transition if active
      if (sceneContextRef.current.isTransitioning && sceneContextRef.current.targetCameraPos) {
        camera.position.lerp(sceneContextRef.current.targetCameraPos, 0.06);
        if (camera.position.distanceTo(sceneContextRef.current.targetCameraPos) < 0.03) {
          camera.position.copy(sceneContextRef.current.targetCameraPos);
          sceneContextRef.current.isTransitioning = false;
        }
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    // 8. Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (isSoftwareGl) {
        clearTimeout(frameId);
      } else {
        cancelAnimationFrame(frameId);
      }
      controls.dispose();
      renderer.dispose();
      outerGeo.dispose();
      innerGeo.dispose();
      ring1Geo.dispose();
      ring2Geo.dispose();
      beaconGeo.dispose();
      plateGeo.dispose();
      shadowGeo.dispose();
      particleGeo.dispose();
      outerCrystalMat.dispose();
      innerCoreMat.dispose();
      ring1Mat.dispose();
      ring2Mat.dispose();
      beaconMat.dispose();
      plateMat.dispose();
      shadowMat.dispose();
      particleMat.dispose();
      monogramTexture.dispose();
      shadowTexture.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update Theme Colors dynamically
  const applyTheme = (theme: ThemePreset) => {
    setActiveTheme(theme);
    const mats = sceneContextRef.current.materials;
    if (!mats) return;

    if (theme === 'emerald') {
      mats.outerCrystal?.color.setHex(0x10b981);
      mats.innerCore?.color.setHex(0x06b6d4);
      mats.innerCore?.emissive.setHex(0x0891b2);
      mats.ring2?.color.setHex(0x34d399);
    } else if (theme === 'cyan') {
      mats.outerCrystal?.color.setHex(0x06b6d4);
      mats.innerCore?.color.setHex(0x3b82f6);
      mats.innerCore?.emissive.setHex(0x2563eb);
      mats.ring2?.color.setHex(0x67e8f9);
    } else if (theme === 'titanium') {
      mats.outerCrystal?.color.setHex(0x94a3b8);
      mats.innerCore?.color.setHex(0xe2e8f0);
      mats.innerCore?.emissive.setHex(0x475569);
      mats.ring2?.color.setHex(0xcbd5e1);
    } else if (theme === 'amber') {
      mats.outerCrystal?.color.setHex(0xf59e0b);
      mats.innerCore?.color.setHex(0xef4444);
      mats.innerCore?.emissive.setHex(0xb91c1c);
      mats.ring2?.color.setHex(0xfbbf24);
    }
  };

  // Wireframe toggle
  const toggleWireframe = () => {
    const next = !wireframe;
    setWireframe(next);
    const mats = sceneContextRef.current.materials;
    if (mats?.outerCrystal) mats.outerCrystal.wireframe = next;
    if (mats?.innerCore) mats.innerCore.wireframe = next;
  };

  // Auto rotate toggle
  const toggleAutoRotate = () => {
    const next = !autoRotate;
    setAutoRotate(next);
    if (sceneContextRef.current.controls) {
      sceneContextRef.current.controls.autoRotate = next;
    }
  };

  // Camera presets with smooth damping
  const setCameraPreset = (preset: 'front' | 'iso' | 'top') => {
    setCameraView(preset);
    const ctx = sceneContextRef.current;
    if (!ctx.camera) return;

    ctx.isTransitioning = true;
    if (preset === 'front') {
      ctx.targetCameraPos = new THREE.Vector3(0, 0, 5.2);
    } else if (preset === 'iso') {
      ctx.targetCameraPos = new THREE.Vector3(3.8, 2.5, 4.2);
    } else if (preset === 'top') {
      ctx.targetCameraPos = new THREE.Vector3(0.01, 5.5, 0.5);
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden transition-all duration-300 ${
        isFullMode
          ? 'fixed inset-0 z-50 h-screen w-screen bg-slate-950'
          : 'h-[360px] md:h-[420px] rounded-2xl border border-slate-800/80 bg-slate-950/70 shadow-2xl'
      }`}
    >
      {/* 3D WebGL Canvas Container */}
      <div
        ref={mountRef}
        className="absolute inset-0 h-full w-full cursor-grab active:cursor-grabbing"
      />

      {/* Top Header Badge & Fullscreen Mode Button */}
      <div className="pointer-events-none absolute top-3 left-3 right-3 flex items-center justify-between z-10">
        <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-slate-700/60 bg-slate-900/90 px-3 py-1.5 text-xs font-medium text-slate-200 shadow-lg">
          {/* Static indicator dot without pulsating animation */}
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          <span>Interactive 3D Prism</span>
          <span className="hidden sm:inline text-slate-500 font-mono">| Three.js r160+ PBR</span>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          {onToggleFullMode && (
            <button
              onClick={onToggleFullMode}
              className="flex items-center gap-1.5 rounded-full border border-slate-700/60 bg-slate-900/90 px-3 py-1.5 text-xs font-medium text-slate-200 shadow-lg hover:border-emerald-500/50 hover:bg-slate-800 transition-colors"
              title={isFullMode ? 'Kembali ke Tampilan CV' : 'Layar Penuh 3D'}
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                {isFullMode ? (
                  <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" />
                ) : (
                  <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
                )}
              </svg>
              <span>{isFullMode ? 'Tutup 3D' : 'Layar Penuh 3D'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Viewport Ergonomic Bottom Dock (Collapsible, solid/rgba surfaces, no backdrop-filter over WebGL) */}
      <div
        className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-[680px]"
      >
        {/* Collapse / Expand Toggle Button */}
        <div className="flex justify-center mb-1.5">
          <button
            onClick={() => setIsControlsOpen(!isControlsOpen)}
            className="pointer-events-auto flex items-center gap-1.5 rounded-full border border-slate-700/80 bg-slate-900 px-3 py-1 text-[11px] font-semibold text-slate-300 shadow-md hover:text-emerald-400 hover:border-emerald-500/50 transition-all"
          >
            <span>{isControlsOpen ? '▾ Sembunyikan Kontrol 3D' : '▴ Buka Panel Kontrol 3D'}</span>
          </button>
        </div>

        {/* Floating Dock Content */}
        {isControlsOpen && (
          <div className="pointer-events-auto rounded-xl border border-slate-800 bg-slate-900/95 p-2.5 text-xs shadow-2xl transition-all duration-200">
            <div className="flex flex-wrap items-center justify-between gap-2.5">
              {/* Presets Finish / Material Theme */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                  Material:
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => applyTheme('emerald')}
                    className={`h-5 px-2 rounded font-medium text-[11px] transition-colors ${
                      activeTheme === 'emerald'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'text-slate-400 hover:text-slate-200 bg-slate-800/80'
                    }`}
                  >
                    Emerald
                  </button>
                  <button
                    onClick={() => applyTheme('cyan')}
                    className={`h-5 px-2 rounded font-medium text-[11px] transition-colors ${
                      activeTheme === 'cyan'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'text-slate-400 hover:text-slate-200 bg-slate-800/80'
                    }`}
                  >
                    Cyan
                  </button>
                  <button
                    onClick={() => applyTheme('titanium')}
                    className={`h-5 px-2 rounded font-medium text-[11px] transition-colors ${
                      activeTheme === 'titanium'
                        ? 'bg-slate-500/20 text-slate-200 border border-slate-400/40'
                        : 'text-slate-400 hover:text-slate-200 bg-slate-800/80'
                    }`}
                  >
                    Titanium
                  </button>
                  <button
                    onClick={() => applyTheme('amber')}
                    className={`h-5 px-2 rounded font-medium text-[11px] transition-colors ${
                      activeTheme === 'amber'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'text-slate-400 hover:text-slate-200 bg-slate-800/80'
                    }`}
                  >
                    Amber
                  </button>
                </div>
              </div>

              {/* Camera Angle Presets */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                  Kamera:
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setCameraPreset('front')}
                    className={`h-5 px-2 rounded text-[11px] font-medium transition-colors ${
                      cameraView === 'front'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Depan
                  </button>
                  <button
                    onClick={() => setCameraPreset('iso')}
                    className={`h-5 px-2 rounded text-[11px] font-medium transition-colors ${
                      cameraView === 'iso'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Perspektif
                  </button>
                  <button
                    onClick={() => setCameraPreset('top')}
                    className={`h-5 px-2 rounded text-[11px] font-medium transition-colors ${
                      cameraView === 'top'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Atas
                  </button>
                </div>
              </div>

              {/* Toggles: Wireframe & Auto-rotate */}
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleWireframe}
                  className={`h-5 px-2 rounded text-[11px] font-medium transition-colors ${
                    wireframe
                      ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Wireframe
                </button>
                <button
                  onClick={toggleAutoRotate}
                  className={`h-5 px-2 rounded text-[11px] font-medium transition-colors ${
                    autoRotate
                      ? 'bg-cyan-500/30 text-cyan-300 border border-cyan-500'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Rotasi: {autoRotate ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
