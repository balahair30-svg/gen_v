export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  type: string;
  description: string;
  highlights: string[];
  techStack: string[];
  accentColor: string;
}

export interface SkillGroup {
  category: string;
  description: string;
  skills: {
    name: string;
    level: number; // 0 - 100
    category: string;
    years: string;
    accentColor: string;
  }[];
}

export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  description: string;
  metrics: string;
  tags: string[];
  role: string;
}

export interface EducationItem {
  degree: string;
  institution: string;
  location: string;
  year: string;
  gpa: string;
  notes: string;
}

export interface CertificationItem {
  name: string;
  issuer: string;
  year: string;
  credentialId: string;
  badgeColor: string;
}

export const cvData = {
  personal: {
    name: 'Nasrul Thiab',
    title: 'Senior Full Stack & 3D Interactive Web Developer',
    address: 'Sumatra Barat, Indonesia',
    email: 'balahair30@gmail.com',
    phone: '0812 7576 9603',
    whatsapp: '6281275769603',
    linkedin: 'linkedin.com/in/nasrul-thiab',
    github: 'github.com/nasrulthiab',
    portfolio: 'nasrulthiab.dev',
    summary:
      'Pengembang web Full Stack dan spesialis WebGL/3D interaktif berpengalaman lebih dari 6 tahun dalam merancang aplikasi web modern berkinerja tinggi, responsif, dan estetis. Mahir dalam arsitektur CSS modular (Inline, Internal, dan External Stylesheet), ekosistem JavaScript/TypeScript modern, React, Three.js, serta pengembangan API backend skalabel. Memiliki rekam jejak terbukti dalam meningkatkan konversi produk digital, efisiensi rendering 3D di browser, dan pengalaman pengguna interaktif.',
    status: 'Tersedia untuk Peluang Full-Time & Konsultasi Kreatif',
  },

  experiences: [
    {
      id: 'exp-1',
      role: 'Lead Full Stack & Creative Web Developer',
      company: 'Tech Solusi Nusantara',
      location: 'Padang, Sumatra Barat (Hybrid)',
      period: 'Januari 2022 – Sekarang',
      type: 'Penuh Waktu',
      description:
        'Memimpin divisi arsitektur frontend dan interaktif, mengarahkan tim insinyur perangkat lunak dalam perancangan platform enterprise terintegrasi dan visualisasi 3D real-time.',
      highlights: [
        'Membangun sistem desain responsif berstandar internasional dengan modularitas CSS hybrid (External tokens + Inline dynamic properties), menurunkan beban CSS sebesar 42%.',
        'Mengembangkan konfigurator produk 3D interaktif berbasis Three.js dengan optimasi shader dan instanced rendering, mendongkrak durasi sesi pengguna sebesar 65%.',
        'Memimpin refaktorisasi arsitektur micro-frontend dari legacy monolith ke Vite + React + Node.js REST API dengan zero-downtime deployment.',
        'Mementori 8+ junior dan mid developer dalam standar penulisan clean code, teknik optimasi rendering DOM, dan aksesibilitas WCAG 2.1.',
      ],
      techStack: ['React 19', 'TypeScript', 'Three.js / WebGL', 'Node.js', 'Tailwind CSS', 'PostgreSQL', 'Docker'],
      accentColor: '#10b981',
    },
    {
      id: 'exp-2',
      role: 'Senior Frontend & UI/UX Specialist',
      company: 'Minang Digital Kreasi Studio',
      location: 'Sumatra Barat',
      period: 'Maret 2019 – Desember 2021',
      type: 'Penuh Waktu',
      description:
        'Bertanggung jawab atas rekayasa antarmuka pengguna responsif kelas atas untuk 30+ klien nasional di sektor pariwisata, e-commerce, dan fintech daerah.',
      highlights: [
        'Mengimplementasikan tata letak responsive multi-device (mobile-first, tablet, desktop, ultra-wide) dengan ketepatan piksel dan skor Google Lighthouse 98+.',
        'Menggubah portal promosi kebudayaan & pariwisata Sumatra Barat dengan tur virtual interaktif berbasis web, dikunjungi lebih dari 450.000 pengguna.',
        'Merancang arsitektur styling internal dan external stylesheet terstandarisasi untuk kecepatan kompilasi dan kemudahan maintenance jangka panjang.',
      ],
      techStack: ['HTML5 & CSS3 Semantic', 'JavaScript ES6+', 'React', 'Sass/SCSS', 'Express.js', 'Figma', 'REST APIs'],
      accentColor: '#06b6d4',
    },
    {
      id: 'exp-3',
      role: 'Full Stack Web Developer & Digital Consultant',
      company: 'Kreatif Studio Mandiri',
      location: 'Sumatra Barat (Remote / Freelance)',
      period: 'Januari 2017 – Februari 2019',
      type: 'Freelance & Kontrak',
      description:
        'Mengembangkan solusi web end-to-end bagi pelaku UMKM dan organisasi profesional, mulai dari perancangan arsitektur database hingga deployment cloud.',
      highlights: [
        'Menyelesaikan 25+ proyek sistem informasi kasir, katalog produk terotomasi, dan landing page konversi tinggi dengan tingkat kepuasan klien 99%.',
        'Meningkatkan performa SEO dan waktu muat halaman hingga 2.1 detik lebih cepat melalui kompresi aset dan styling CSS teroptimasi.',
      ],
      techStack: ['HTML/CSS/JS', 'PHP & Laravel', 'MySQL', 'Bootstrap & Custom CSS', 'Git & CI/CD'],
      accentColor: '#f59e0b',
    },
  ] as ExperienceItem[],

  skillGroups: [
    {
      category: 'Teknik Styling & Desain Web (HTML & CSS)',
      description: 'Penguasaan mendalam 3 teknik CSS: Inline Style, Internal Style, dan External Stylesheet',
      skills: [
        { name: 'HTML5 Semantic & SEO', level: 98, category: 'Core Web', years: '7+ thn', accentColor: '#10b981' },
        { name: 'External Stylesheet Architecture', level: 96, category: 'CSS System', years: '6+ thn', accentColor: '#8b5cf6' },
        { name: 'Internal Styles (<style> & Animations)', level: 94, category: 'CSS System', years: '6+ thn', accentColor: '#06b6d4' },
        { name: 'Inline Dynamic Styles & CSS Variables', level: 95, category: 'CSS System', years: '6+ thn', accentColor: '#f59e0b' },
        { name: 'Responsive Web Design (Flexbox & Grid)', level: 97, category: 'Layout', years: '7+ thn', accentColor: '#10b981' },
        { name: 'Print Media Queries (@media print)', level: 92, category: 'Layout', years: '5+ thn', accentColor: '#34d399' },
      ],
    },
    {
      category: 'Frontend & 3D Interactive WebGL',
      description: 'Ekosistem pengembangan frontend modern dan grafis 3D interaktif real-time',
      skills: [
        { name: 'JavaScript ES6+ & TypeScript', level: 95, category: 'Programming', years: '6+ thn', accentColor: '#f59e0b' },
        { name: 'React.js & Next.js Ecosystem', level: 94, category: 'Frontend', years: '5+ thn', accentColor: '#06b6d4' },
        { name: 'Three.js & PBR 3D Graphics', level: 90, category: 'Creative Tech', years: '4+ thn', accentColor: '#10b981' },
        { name: 'Tailwind CSS & Utility-First', level: 96, category: 'Styling', years: '5+ thn', accentColor: '#38bdf8' },
        { name: 'Web Performance & Core Web Vitals', level: 91, category: 'Optimization', years: '5+ thn', accentColor: '#10b981' },
      ],
    },
    {
      category: 'Backend, Database & DevOps',
      description: 'Infrastruktur server, database relasional/NoSQL, dan otomatisasi alur kerja',
      skills: [
        { name: 'Node.js & Express.js', level: 90, category: 'Backend', years: '5+ thn', accentColor: '#22c55e' },
        { name: 'RESTful API & GraphQL Design', level: 92, category: 'API', years: '5+ thn', accentColor: '#06b6d4' },
        { name: 'PostgreSQL, MySQL & Firebase', level: 88, category: 'Database', years: '6+ thn', accentColor: '#3b82f6' },
        { name: 'Git, GitHub Actions & CI/CD', level: 92, category: 'DevOps', years: '6+ thn', accentColor: '#ec4899' },
        { name: 'Docker & Cloud Deployment', level: 85, category: 'Infrastructure', years: '4+ thn', accentColor: '#6366f1' },
      ],
    },
  ] as SkillGroup[],

  projects: [
    {
      id: 'proj-1',
      title: 'Minang Heritage 3D Interactive Virtual Tour',
      category: '3D WebGL & Creative Web',
      description:
        'Aplikasi penjelajahan interaktif arsitektur Rumah Gadang dan budaya Minangkabau dengan rendering Three.js PBR, pencahayaan studio procedural, dan navigasi 360 derajat.',
      metrics: '450.000+ Pengunjung Unik | 60 FPS di Mobile',
      tags: ['Three.js', 'React', 'CSS Grid', 'WebGL Shaders', 'Audio API'],
      role: 'Lead Architect & 3D Specialist',
    },
    {
      id: 'proj-2',
      title: 'Enterprise ERP & Manajemen Logistik Sumatra Barat',
      category: 'Full Stack Web Platform',
      description:
        'Sistem enterprise terintegrasi untuk pemantauan distribusi komoditas daerah Sumatra Barat secara real-time dengan dashboard analitik dan ekspor laporan otomatis.',
      metrics: 'Memangkas waktu rekonsiliasi data sebesar 70%',
      tags: ['TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind', 'Docker'],
      role: 'Full Stack Engineer',
    },
    {
      id: 'proj-3',
      title: 'Omnichannel E-Commerce & Product 3D Configurator',
      category: 'E-Commerce & High Conversion',
      description:
        'Toko online modern dengan fitur kustomisasi produk 3D real-time, integrasi payment gateway nasional, dan arsitektur styling CSS hybrid berbobot ultra-ringan.',
      metrics: '+38% Konversi Penjualan | Skor Lighthouse 99',
      tags: ['React', 'Next.js', 'Three.js', 'Stripe/Midtrans', 'External CSS'],
      role: 'Frontend & UI Engineer',
    },
  ] as ProjectItem[],

  education: [
    {
      degree: 'Sarjana Komputer (S.Kom) - Teknik Informatika / Sistem Informasi',
      institution: 'Universitas Terkemuka di Sumatra Barat',
      location: 'Sumatra Barat, Indonesia',
      year: '2013 – 2017',
      gpa: 'IPK: 3.82 / 4.00 (Dengan Pujian / Cum Laude)',
      notes: 'Fokus Riset: Optimasi Rendering Antarmuka Grafis dan Sistem Basis Data Terdistribusi.',
    },
  ] as EducationItem[],

  certifications: [
    {
      name: 'Meta Certified Professional Frontend Developer',
      issuer: 'Meta (Facebook)',
      year: '2023',
      credentialId: 'META-FED-884920',
      badgeColor: '#06b6d4',
    },
    {
      name: 'Advanced Three.js & WebGL Visual Craftsman',
      issuer: 'Three.js Journey / Bruno Simon Certification',
      year: '2022',
      credentialId: 'THREEJS-CERT-3910',
      badgeColor: '#10b981',
    },
    {
      name: 'Google Cloud Certified: Cloud DevOps Engineer',
      issuer: 'Google Cloud Platform',
      year: '2021',
      credentialId: 'GCP-DEVOPS-99214',
      badgeColor: '#3b82f6',
    },
    {
      name: 'Responsive Web Design & Modern CSS Architecture',
      issuer: 'freeCodeCamp International',
      year: '2020',
      credentialId: 'FCC-RWD-77123',
      badgeColor: '#f59e0b',
    },
  ] as CertificationItem[],

  languages: [
    { name: 'Bahasa Indonesia', level: 'Penutur Asli (Native)', proficiency: 100 },
    { name: 'Bahasa Minang', level: 'Penutur Asli Daerah (Native)', proficiency: 100 },
    { name: 'Bahasa Inggris', level: 'Kemampuan Kerja Profesional (Professional Working)', proficiency: 88 },
  ],

  // Explanatory breakdown of the 3 CSS techniques used in this CV
  cssTechniquesDoc: [
    {
      type: 'External Stylesheet',
      color: '#8b5cf6',
      badge: 'EXTERNAL CSS',
      location: '/src/cv-external.css',
      purpose:
        'Digunakan untuk struktur pondasi global, variabel CSS root (warna tema, radius, bayangan), grid responsif multi-kolom, reset tipografi, dan media cetak (@media print).',
      benefits:
        'Memisahkan logika tampilan sepenuhnya dari markup, memudahkan pemeliharaan global (maintainability), dan memanfaatkan browser caching secara optimal.',
    },
    {
      type: 'Internal Style',
      color: '#06b6d4',
      badge: 'INTERNAL CSS',
      location: '<style id="cv-internal-styles"> dalam dokumen',
      purpose:
        'Digunakan untuk keyframe animations khusus (@keyframes shimmer, float, pulse), efek visual khusus komponen, dan styling halaman spesifik yang eksklusif pada lembar CV ini.',
      benefits:
        'Terdokumentasi langsung bersama halaman, tidak bergantung pada muatan HTTP eksternal tambahan, dan ideal untuk animasi serta aturan gaya scoped.',
    },
    {
      type: 'Inline Style',
      color: '#f59e0b',
      badge: 'INLINE CSS',
      location: 'Atribut style="..." / style={{ ... }} pada elemen HTML/JSX',
      purpose:
        'Digunakan untuk nilai-nilai dinamis berbasis data runtime (seperti persentase meter keterampilan width: skill.level%, warna aksen spesifik tiap peran pekerjaan, dan kalkulasi dinamis).',
      benefits:
        'Memiliki spesifisitas tertinggi untuk override dinamis, sangat cocok untuk kalkulasi runtime JavaScript tanpa perlu membuat ratusan class utilitas statis.',
    },
  ],
};
